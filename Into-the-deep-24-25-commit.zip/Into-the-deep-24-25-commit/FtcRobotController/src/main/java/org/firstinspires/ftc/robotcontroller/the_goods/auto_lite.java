package org.firstinspires.ftc.robotcontroller.auto2;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import com.qualcomm.robotcore.hardware.DcMotor;

import com.qualcomm.robotcore.hardware.CRServo;

@Autonomous
public class auto_lite extends LinearOpMode {
    public static double inches(int inch) {
        return (inch * 41.81);
    }


    DcMotor frontRight;
    DcMotor frontLeft;
    DcMotor backLeft;
    DcMotor backRight;
    DcMotor arm = hardwareMap.dcMotor.get("arm");
    DcMotor intakeArm = hardwareMap.dcMotor.get("intakeArm");
    CRServo ser = hardwareMap.crservo.get("intake");
    double pi = Math.PI;
    double encoderRes = 537.7; // Encoder resolution (ticks per revolution)
    double diameter = 3.77952755906; // Wheel diameter in inches

    double spin = diameter * pi / encoderRes; // Calculate distance per encoder tick

    // Function to set power to all four motors
    public void move(double forward, double turn, double strafe, double targetInches) {
        forward = -forward;
        int travel = 0;
        int travel2 = 0;
        int travel3 = 0;
        int travel4 =0;
        reset();
        double enc = inches((int) targetInches); //translates the target inches back to encoder units
        frontLeft.setPower(forward+turn+strafe);
        frontRight.setPower(forward-turn-strafe);
        backLeft.setPower(forward+turn-strafe);
        backRight.setPower(forward-turn+strafe);
        while(opModeIsActive()){
            travel = Math.abs(frontLeft.getCurrentPosition());
            travel2 = Math.abs(frontRight.getCurrentPosition());
            travel3 =Math.abs(backLeft.getCurrentPosition());
            travel4 = Math.abs(backRight.getCurrentPosition());

            double stop = Math.max(Math.max(travel,travel2),Math.max(travel3,travel4));
            if (stop>= enc) {
                frontLeft.setPower(0);
                frontRight.setPower(0);
                backLeft.setPower(0);
                backRight.setPower(0);
                break;

            } else {
                telemetry.addData("target", targetInches);
                telemetry.addData("current", travel);
            }
        }
    }


    public void arm_select(String arm_choice,double speed, double time_seconds){
        time_seconds = time_seconds * 1000;
        if (arm_choice == "arm"){
            arm.setPower(speed);
            sleep((long)time_seconds);
            arm.setPower(0);
        } else if (arm_choice == "intake") {
            intakeArm.setPower(speed);
            sleep((long) time_seconds);
            intakeArm.setPower(0);
        } else if (arm_choice == "ser") {
            ser.setPower(speed);
            sleep((long) time_seconds);
            ser.setPower(0);
        }
    }



    //resets encoders because im not typing all that every time i change movement
    public void reset() {
        frontLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontLeft.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER); // Set to run without encoder tracking but why???
        frontRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontRight.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
    }



    @Override
    public void runOpMode() throws InterruptedException {



        // Initialize mecanum drive motors and auxiliary motors
        DcMotor frontLeft = hardwareMap.dcMotor.get("frontLeft");
        DcMotor backLeft = hardwareMap.dcMotor.get("backLeft");
        DcMotor frontRight = hardwareMap.dcMotor.get("frontRight");
        DcMotor backRight = hardwareMap.dcMotor.get("backRight");
        DcMotor arm = hardwareMap.dcMotor.get("arm");
        CRServo ser = hardwareMap.crservo.get("intake");
        //no spin mode
        frontLeft.setDirection(DcMotor.Direction.REVERSE);
        backLeft.setDirection(DcMotor.Direction.REVERSE);


        waitForStart();



        //autonomous reloaded.


        //movement in all vectors, oh yea! sry mb i had to.
        move(.3,.3,0,12); //example negative numbers for the opposite direction. in this case moving forward, turning right, and not strafing
        //this will stop after it reaches 12 inches
        arm_select("arm",.5,1); //so far only 3 arm options that i know of so. the arm
        arm_select("intake",.3,.5);//sliding arm i think
        arm_select("ser",1,.5);//and claw or servo depending on what we go with.

        //to use arm select first type the name of one of the arm options in all lowercase like in the example, then the speed, and the time they run in seconds



    }
}
