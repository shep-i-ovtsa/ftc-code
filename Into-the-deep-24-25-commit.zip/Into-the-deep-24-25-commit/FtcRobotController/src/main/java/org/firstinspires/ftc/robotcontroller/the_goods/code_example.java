
package org.firstinspires.ftc.teamcode;

//import com.a
//import com.acmerobotics.dashboard.FtcDashboard;
//import com.acmerobotics.dashboard.config.Config;
//import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
// import org.firstinspires.ftc.teamcode.Gyro;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.ElapsedTime;

public int convert(int inches) {
    // Convert inches to encoder counts using a scaling factor
    return inches * 41.81;
}

@Autonomous
public class bluePark extends LinearOpMode {

    // Declare motor variables for the drivetrain
    DcMotor frontRight;
    DcMotor frontLeft;
    double pi = Math.PI;
    double encoderRes = 537.7; // Encoder resolution (ticks per revolution)
    double diameter = 3.77952755906; // Wheel diameter in inches

    double spin = diameter * pi / encoderRes; // Calculate distance per encoder tick

    public static double Straight1Move = 42; // Placeholder for straight movement distance
    public static double Straight2Move = 0.5; // Placeholder for straight movement power

    // Function to set power to all four motors
    public void move(double frontLeftPower, double frontRightPower, double backLeftPower, double backRightPower) {
        frontLeft.setPower(frontLeftPower);
        frontRight.setPower(frontRightPower);
        backLeft.setPower(backLeftPower);
        backRight.setPower(backRightPower);
    }

    @Override
    public void runOpMode() throws InterruptedException {
        int travel = 0;
        int travel2 = 0;
        // Initialize mecanum drive motors and auxiliary motors
        DcMotor frontLeft = hardwareMap.dcMotor.get("frontLeft");
        DcMotor backLeft = hardwareMap.dcMotor.get("backLeft");
        DcMotor frontRight = hardwareMap.dcMotor.get("frontRight");
        DcMotor backRight = hardwareMap.dcMotor.get("backRight");
        DcMotor arm = hardwareMap.dcMotor.get("arm");
        DcMotor intakeArm = hardwareMap.dcMotor.get("intakeArm");
        CRServo ser = hardwareMap.crservo.get("intake");

        // Reverse direction of left motors for correct mecanum movement
        frontLeft.setDirection(DcMotor.Direction.REVERSE);
        backLeft.setDirection(DcMotor.Direction.REVERSE);

        // Wait for the game to start
        waitForStart();

        // Reset and configure encoders for tracking distance
        frontLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontLeft.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER); // Set to run without encoder tracking
        frontRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontRight.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER); // Set to run without encoder tracking

        // Initialize variables for tracking encoder counts
        int travel = 0;
        int travel2 = 0;
        int targetInches = convert(48); // Target distance in encoder counts

        // Move straight forward until the target distance is reached
        while ((travel < targetInches) || (travel2 < targetInches)) {
            travel2 = frontRight.getCurrentPosition(); // Get current position of front right motor
            travel = frontLeft.getCurrentPosition();  // Get current position of front left motor

            // Display target and current encoder counts for debugging
            telemetry.addData("target", targetInches);
            telemetry.addData("current", travel);

            // Move forward if either motor hasn't reached the target
            if (travel < targetInches || travel2 < targetInches) {
                move(0.3, 0.3, 0.3, 0.3); // Forward movement with equal power
            }

            telemetry.update();
        }
        move(0, 0, 0, 0); // Stop motors
        sleep(1000);

        // Hang the specimen
        arm.setPower(0.5);
        sleep(1000);
        arm.setPower(0);

        intakeArm.setPower(0.3);
        sleep(500);
        intakeArm.setPower(0);

        ser.setPower(1.0);
        sleep(500);
        ser.setPower(0);

        sleep(1000);

        arm.setPower(-0.5);
        sleep(1000);
        arm.setPower(0);

        intakeArm.setPower(-0.3);
        sleep(500);
        intakeArm.setPower(0);

        // Strafe left for the specified distance
        frontLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontLeft.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER); // Set to run without encoder tracking
        frontRight.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER); // Set to run without encoder tracking
        travel = 0;
        targetInches = convert(48); // Target distance for strafing

        while (travel < targetInches) {
            travel = frontLeft.getCurrentPosition(); // Get current position of front left motor

            // Display target and current encoder counts for debugging
            telemetry.addData("target", targetInches);
            telemetry.addData("current", travel);

            move(-0.3, 0.3, 0.3, -0.3); // Strafe left
            telemetry.update();
        }
        move(0, 0, 0, 0); // Stop motors
        sleep(1000);

// Reset and configure encoders for tracking distance
        frontLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontLeft.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER); // Set to run without encoder tracking
        frontRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontRight.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER); // Set to run without encoder tracking

        // Initialize variables for tracking encoder counts
        int travel = 0;
        int travel2 = 0;
        int targetInches = convert(48); // Target distance in encoder counts

        // Move straight forward until the target distance is reached
        while ((travel < targetInches) || (travel2 < targetInches)) {
            travel2 = frontRight.getCurrentPosition(); // Get current position of front right motor
            travel = frontLeft.getCurrentPosition();  // Get current position of front left motor

            // Display target and current encoder counts for debugging
            telemetry.addData("target", targetInches);
            telemetry.addData("current", travel);

            // Move forward if either motor hasn't reached the target
            if (travel < targetInches || travel2 < targetInches) {
                move(0.3, 0.3, 0.3, 0.3); // Forward movement with equal power
            }

            telemetry.update();
        }
        move(0, 0, 0, 0); // Stop motors
        sleep(1000);



        // Reset encoders after strafe and before turn
        frontLeft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontLeft.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER); // Set to run without encoder tracking
        frontRight.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        frontRight.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER); // Set to run without encoder tracking
        travel = 0;
        targetInches = convert(48); // Target distance for turning

        // Turn right for the specified distance
        while (travel < targetInches) {
            travel = frontLeft.getCurrentPosition(); // Get current position of front left motor

            // Display target and current encoder counts for debugging
            telemetry.addData("target", targetInches);
            telemetry.addData("current", travel);

            move(0.3, -0.3, 0.3, -0.3); // Turn right
            telemetry.update();
        }
        move(0, 0, 0, 0); // Stop motors
        sleep(1000);

        // Level 1 ascent to touch the bar
        arm.setPower(0.3); // Raise the arm slightly
        sleep(1000);       // Adjust time as needed
        arm.setPower(0);   // Stop the arm

        // End of autonomous routine
        telemetry.addData("Status", "Autonomous Complete");
        telemetry.update();
    }
}




